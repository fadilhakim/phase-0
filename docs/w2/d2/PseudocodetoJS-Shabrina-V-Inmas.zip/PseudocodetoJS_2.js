var alas = prompt("Alas segitiga: ","");
var tinggi = prompt ("Tinggi segitiga: ", "");

var luasSegitiga = alas*tinggi/2;

console.log("Luas Segitiga: "+ luasSegitiga);
