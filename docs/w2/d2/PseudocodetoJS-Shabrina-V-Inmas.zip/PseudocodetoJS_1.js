var nama = prompt("Nama: ","");
var aPembilang = prompt ("Angka Pembilang: ", "");
var aPenyebut = prompt ("Angka Penyebut: ", "");

var hasil = aPembilang/aPenyebut;

console.log("Halo " + nama + ", " + aPembilang + " dibagi " + aPenyebut + " adalah sama dengan "+ hasil);
