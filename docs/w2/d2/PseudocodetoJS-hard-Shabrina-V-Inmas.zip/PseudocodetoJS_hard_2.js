var pagar = "";

for (var i=1; i<=10; i++) {
  for (var j=0; j<=10; j++) {
    pagar += "#";
    console.log(j);
  }
  console.log(pagar);
  pagar = "";
}
